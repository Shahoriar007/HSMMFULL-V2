@extends('masterAdmin')
@section('adminDashboard')

<!-- content @s -->

<!-- content @e -->

@endsection