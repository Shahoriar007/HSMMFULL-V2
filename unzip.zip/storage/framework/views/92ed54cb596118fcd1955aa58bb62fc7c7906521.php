
                <!----------------------------------------------- Body Part End ---------------------------------------------->
                


               
                </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->

  

  
</body><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\hsmmu new\HSMMUFull\resources\views/teacher/teacherFooter.blade.php ENDPATH**/ ?>