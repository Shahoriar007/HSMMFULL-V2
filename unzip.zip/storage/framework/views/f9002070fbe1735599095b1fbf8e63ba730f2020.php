<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('adminFrontend/images/favicon.png')); ?>">
    <!-- Page Title  -->
    <title></title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/dashlite.css?ver=3.1.1')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('adminFrontend/assets/css/theme.css?ver=3.1.1')); ?>">

        
    <link rel="stylesheet" type="text/css" 
     href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>

<?php echo $__env->make('teacher.teacherNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('teacherDashboard'); ?>
    <?php echo $__env->yieldContent('scheduleView'); ?>
    <?php echo $__env->yieldContent('salaryView'); ?>
    <?php echo $__env->yieldContent('changeTeacherPassword'); ?>
    

    
<?php echo $__env->make('teacher.teacherFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- JavaScript -->
    <script src="<?php echo e(asset('adminFrontend/assets/js/bundle.js?ver=3.1.1')); ?>"></script>
    <script src="<?php echo e(asset('adminFrontend/assets/js/scripts.js?ver=3.1.1')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"> </script>
    <script src="<?php echo e(asset('adminFrontend/assets/js/ckeditor.js')); ?>"></script>

    
<!----Jquery----->
<script src="<?php echo e(asset('adminFrontend/assets/js/jquery-3.6.0.min.js')); ?>"></script>
<!--=====popper js=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/popper.min.js')); ?>"></script>
<!--=====bootstrap=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/bootstrap.min.js')); ?>"></script>
<!--=====Owl carousel=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/owl.carousel.min.js')); ?>"></script>
<!--=====header script=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/script.js')); ?>"></script>
<!--=====header script=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/main.js')); ?>"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch(type){
        case 'info':
            toastr.info(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'success':
            toastr.success(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'warning':
            toastr.warning(" <?php echo e(Session::get('message')); ?> ");
        break;
        case 'error':
            toastr.error(" <?php echo e(Session::get('message')); ?> ");
        break;
    }
    <?php endif; ?>
</script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script type="text/javascript">
        $(function(){
            $(document).on('click','#delete',function(e){
                e.preventDefault();
                var link = $(this).attr("href");
                Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = link
                    Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                    )
                }
                })
            });
        });
    </script>



</html><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/masterTeacher.blade.php ENDPATH**/ ?>