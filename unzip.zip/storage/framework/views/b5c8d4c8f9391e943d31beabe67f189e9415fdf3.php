
<?php $__env->startSection('onlineApplicationsDetails'); ?>



<br><br><br>

<form method="POST" action="<?php echo e(route('studentFormsetupSubmit')); ?>">
    <?php echo csrf_field(); ?>
    
  <div class="form-group col-md-4">
    <label for="labelName">Label Name</label>
    <input type="text" id="labelName" name="labelName" class="form-control"  >
  </div>
  <div class="form-group col-md-4">
    <label for="relatedField">Select Field</label>
    <select id="relatedField" name="relatedField" class="form-control" >

    <?php $__currentLoopData = $formfields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($fields->labelName == null): ?>

            <option value="<?php echo e($fields->relatedField); ?>"><?php echo e($fields->relatedField); ?></option>

        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\school_management-v1\hsmm\laravel_Breeze_MultiAuth-48afd2e0b99bda872f7a0f3f0b9961d3cb8e5c94\resources\views/admin/adminSection/student_applicationform_setup.blade.php ENDPATH**/ ?>