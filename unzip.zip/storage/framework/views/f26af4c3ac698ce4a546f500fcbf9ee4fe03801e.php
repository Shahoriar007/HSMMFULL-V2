
<?php $__env->startSection('onlineApplications'); ?>




<head>
<style>
/* table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
} */
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>


</head>
<body>

<div>
    <a href=""> Dashboard</a>
</div>
<br><br>

<h2 class="text-center">Online Applicatrion Table</h2>



<div style="overflow-x:auto;">
<table >
  <tr>
    <th>Id</th>
    <th>Student Name</th>
    <th>Want to Admitted in</th>
    <th>Father Name</th>
    <th>Father Phone</th>
    <th>Current Address</th>

    <th colspan="2" class="text-center">Action</th>
  </tr>

<?php $__currentLoopData = $onlineAdmInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($info->id); ?></td>
        <td><?php echo e($info->studentname_in_english); ?></td>
        <td><?php echo e($info->seeking_admission_class); ?></td>
        <td><?php echo e($info->fathername_in_english); ?></td>
        <td><?php echo e($info->phoneNumber_father); ?></td>
        <td><?php echo e($info->current_address); ?></td>

        <!-- Details Button -->
        <td>
            <a href="<?php echo e(url('/admin/online_applications')); ?>/<?php echo e($info->id); ?>">
                <button type="button" class="btn btn-primary">Details</button>
            </a>
        </td>

        <!-- Delete Button -->
        <td>
            <a href="" id="delete">
                <button type="button" class="btn btn-danger">Delete</button>
            </a>
        </td>

    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<!-- Pagination -->
<br>
<br>
<div class="row justify-content-md-center">
  <div class="col-md-auto">
  
  </div> 
</div>
<br>
<br>

</div>

</body>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\school_management-v1\hsmm\laravel_Breeze_MultiAuth-48afd2e0b99bda872f7a0f3f0b9961d3cb8e5c94\resources\views/admin/adminSection/online_applications.blade.php ENDPATH**/ ?>