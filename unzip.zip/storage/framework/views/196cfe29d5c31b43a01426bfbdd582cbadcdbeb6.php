
<?php $__env->startSection('adminDashboard'); ?>

<!-- content @s -->

<!-- content @e -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\hsmmu new\HSMMUFull\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>