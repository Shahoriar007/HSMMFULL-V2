
<?php $__env->startSection('class'); ?>

<!-- content @s -->
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">


                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">

                        </div>

                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="card-head">
                                    <h5 class="card-title">Add Class Teacher</h5>
                                </div>

                                <form class="gy-3" method="POST" action="<?php echo e(route('classTeacherSetSubmit')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="row g-3 align-center">

                                        <?php

                                        $classSection = \App\Models\Classinfo::all();

                                        ?>



                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">

                                                    <label for="class">Choose Class:</label>
                                                    <select class="form-control" name="classTeacherClass"
                                                        id="classTeacherClass">

                                                        <?php $__currentLoopData = $classSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($classInfo->class); ?>"><?php echo e($classInfo->class); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">

                                                    <label for="class">Choose Section:</label>
                                                    <select class="form-control" name="classTeacherSection"
                                                        id="classTeacherSection">

                                                        <?php $__currentLoopData = $classSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($sectionInfo->section); ?>">
                                                            <?php echo e($sectionInfo->section); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">

                                                    <label for="class">Teacher Id</label>
                                                    <input class="form-control" id="teacherId" type="text"
                                                        name="teacherId" placeholder="Teacher id">
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row g-3">
                                        <div class="col-lg-7 offset-lg-5">
                                            <div class="form-group mt-2">
                                                <button type="submit" class="btn btn-lg btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div><!-- card -->
                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="card-head">
                                    <h5 class="card-title">All Classes and Sections</h5>
                                </div>
                                <div>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="pro-id">Class</th>
                                                <th class="pro-title">Section</th>
                                                <th class="pro-status">Teacher ID</th>
                                                <th class="pro-status">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $classTeacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classTeacherInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($classTeacherInfo->classTeacherClass); ?></td>
                                                <td><?php echo e($classTeacherInfo->classTeacherSection); ?></td>
                                                <td><?php echo e($classTeacherInfo->teacherId); ?></td>
                                                <td>

                                                    <a href="<?php echo e(url('/admin/classTeacherSet/delete')); ?>/<?php echo e($classTeacherInfo->teacherId); ?>"
                                                        class="btn btn-danger">Delete</a>

                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>

                    </div><!-- .nk-block -->

                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>
<!-- content @e -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\hsmmu new\HSMMUFull\resources\views/admin/adminSection/classTeacherSet.blade.php ENDPATH**/ ?>