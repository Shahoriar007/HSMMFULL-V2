<?php $__env->startSection('userDashboard'); ?>
<!--Body Content-->


<!--End Body Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterStudent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\hsmmu new\HSMMUFull\resources\views/dashboard.blade.php ENDPATH**/ ?>