
<?php $__env->startSection('onlineApplications'); ?>

                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="components-preview wide-md mx-auto">
                                    

                                    <div class="nk-block nk-block-lg">
                                        <div class="nk-block-head">
                                            <div class="nk-block-head-content">
                                                <h4 class="title nk-block-title">Class, section, roll  input Section</h4>
                                                <div class="nk-block-des">
                                                    <p>You can make style out your setting related form as per below example.</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card card-bordered">
                                            <div class="card-inner">
                                               

                                                <form class="gy-3" method="POST" action="<?php echo e(route('admission_form_approve', $studentInfo->id)); ?>" >
                                                <?php echo csrf_field(); ?>

                                                <input type="hidden" name="id" value="<?php echo e($studentInfo->id); ?>">
                                                <input type="hidden" name="studentname_in_english" value="<?php echo e($studentInfo->studentname_in_english); ?>">
                                                <input type="hidden" name="status" value="<?php echo e($studentInfo->status); ?>">
                                                

                                                <div class="row g-3 align-center">
                                                        <div class="col-lg-5">
                                                            <div class="form-group">
                                                                <label class="form-label" for="site-name">Class</label>
                                                                <span class="form-note">Specify the class you want to.</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7">
                                                            <div class="form-group">
                                                                <div class="form-control-wrap">
                                                                    <input class="form-control" type="text" id="admitted_class" name="admitted_class" value="<?php echo e($studentInfo->admitted_class); ?>" placeholder="<?php echo e($studentInfo->admitted_class); ?>" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       
                                                </div>
                                                <div class="row g-3 align-center">
                                                        <div class="col-lg-5">
                                                            <div class="form-group">
                                                                <label class="form-label" for="site-name">Section</label>
                                                                <span class="form-note">Specify the class you want to.</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7">
                                                            <div class="form-group">
                                                                <div class="form-control-wrap">
                                                                    <input class="form-control" type="text" id="admitted_section" name="admitted_section" value="<?php echo e($studentInfo->admitted_section); ?>" placeholder="<?php echo e($studentInfo->admitted_section); ?>" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       
                                                </div>
                                               
                                                <div class="row g-3 align-center">
                                                        <div class="col-lg-5">
                                                            <div class="form-group">
                                                                <label class="form-label" for="site-name">Roll</label>
                                                                <span class="form-note">Specify the class you want to.</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7">
                                                            <div class="form-group">
                                                                <div class="form-control-wrap">
                                                                    <input class="form-control" type="text" id="roll" name="roll" value="<?php echo e($studentInfo->roll); ?>" placeholder="<?php echo e($studentInfo->admitted_section); ?>" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       
                                                </div>

                                                <div class="row g-3 align-center">
                                                        <div class="col-lg-5">
                                                            <div class="form-group">
                                                                <label class="form-label" for="site-name">Tution Fee</label>
                                                                <span class="form-note">Specify the class you want to.</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7">
                                                            <div class="form-group">
                                                                <div class="form-control-wrap">
                                                                    <input class="form-control" type="text" id="tution_fee" name="tution_fee" value="<?php echo e($studentInfo->tution_fee); ?>" placeholder="<?php echo e($studentInfo->tution_fee); ?>" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       
                                                </div>

                                                    
                                                    <div class="row g-3">
                                                        <div class="col-lg-7 offset-lg-5">
                                                            <div class="form-group mt-2">
                                                                <button type="submit" class="btn btn-lg btn-primary">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>

                                        </div><!-- card -->

                                    </div><!-- .nk-block -->

                                </div><!-- .components-preview -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/admin/adminSection/online_applications_approve_input.blade.php ENDPATH**/ ?>