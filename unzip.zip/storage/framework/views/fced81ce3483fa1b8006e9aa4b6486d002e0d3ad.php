
<?php $__env->startSection('salaryView'); ?>
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">


                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">

                        </div>

                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="row">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="product-name alt-font">Year</th>
                                                <th class="product-price text-center alt-font">Month</th>
                                                <th class="stock-status text-center alt-font">Amount</th>
                                                <th class="product-subtotal text-center alt-font">Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($salaries): ?>
                                            <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->year); ?></td>
                                                <td><?php echo e($item->month); ?></td>
                                                <td><?php echo e($item->salary); ?></td>
                                                <td>

                                                    <?php echo e($item->status); ?>

                                                    </select>
                                                </td>
                                               
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                        <?php $__env->stopSection(); ?>
<?php echo $__env->make('masterTeacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\HSMMU\resources\views/salaryview.blade.php ENDPATH**/ ?>