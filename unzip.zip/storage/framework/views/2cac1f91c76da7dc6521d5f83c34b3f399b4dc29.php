
<?php $__env->startSection('scheduleView'); ?>

<!-- content @s -->
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">


                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">

                        </div>

                        <div class="card card-bordered">
                            <div class="card-inner">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <form action="<?php echo e(route('classRoutine')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <select name="day" id="day">
                                            
                                                <option value="saturday">saturday</option>
                                                <option value="sunday">Sunday</option>
                                                <option value="monday">Monday</option>
                                                <option value="tuesday">Tuesday</option>
                                                <option value="wednesday">wednesday</option>
                                                <option value="thursday">Thursday</option>
                                            </select>
                                            <button type="submit"> Submit</button>
                                        </form>
                                    </div>
                                    <div class="col-lg-8">
                                        <table class="table table-bordered">
                                            <thead>
                                                <th>start time</th>
                                                <th>end time</th>
                                                <th>class</th>
                                                <th>section</th>
                                                <th>subject</th>
                                                <th>day</th>
                                            </thead>
                                            <tbody>
                                                <?php if($schedules): ?>
                                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <td><?php echo e($schedule->start_time); ?></td>
                                                <td><?php echo e($schedule->end_time); ?></td>
                                                <td><?php echo e($schedule->class); ?></td>
                                                <td><?php echo e($schedule->section); ?></td>
                                                <td><?php echo e($schedule->subject); ?></td>
                                                <td><?php echo e($schedule->day); ?></td>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>



                            </div>

                        </div><!-- card -->


                    </div><!-- .nk-block -->

                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>


<!-- content @e -->
<!----Jquery----->
<script src="<?php echo e(asset('adminFrontend/assets/js/jquery-3.6.0.min.js')); ?>"></script>
<!--=====popper js=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/popper.min.js')); ?>"></script>
<!--=====bootstrap=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/bootstrap.min.js')); ?>"></script>
<!--=====Owl carousel=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/owl.carousel.min.js')); ?>"></script>
<!--=====header script=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/script.js')); ?>"></script>
<!--=====header script=====-->
<script src="<?php echo e(asset('adminFrontend/assets/js/main.js')); ?>"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/Javascript">
    $(".status").on("change", function() {
        var $select = $(this);
        var id = $select.parent().prev().find("input#slider_id").val();
        var status = $select.val();
        console.log(id,status);
        $.ajaxSetup({
       headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       }
   });

   $.ajax({
            type:'POST',
            url:"<?php echo e(route('updateSliderStatus')); ?>",
            data: {id:id,status:status},
            success:function(data){
                console.log('hiiiiiiiiiiiiiiiiii');
          }
       });
        

    });
</script>



<?php $__env->stopSection(); ?>




<!-- <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('createSlider')); ?>">
            <?php echo csrf_field(); ?>

  <label for="sliderText">Text</label><br>
  <input type="text" id="sliderText" name="sliderText" value=""><br><br>
  <label for="image">image</label><br>
  <input type="file" id="image" name="image" />
    </select>
    <input type="submit" value="Submit">
   

        </form> -->
<?php echo $__env->make('masterTeacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Laravel\Aveenir IT\School_management\hsmmu new\HSMMUFull\resources\views/scheduleView.blade.php ENDPATH**/ ?>